/* Motivation Screen — settings & library UI. Talks to the C# host with chrome.webview messages. */
'use strict';

window.__msErrors = [];
window.addEventListener('error', (e) => window.__msErrors.push(String(e.message) + ' @' + e.lineno));
window.addEventListener('unhandledrejection', (e) => window.__msErrors.push('promise: ' + String(e.reason)));

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const wv = window.chrome && window.chrome.webview;

const host = {
  post(msg) { if (wv) wv.postMessage(msg); else Mock.handle(msg); },
  postFiles(msg, files) { if (wv && wv.postMessageWithAdditionalObjects) wv.postMessageWithAdditionalObjects(msg, files); else host.post(msg); },
};

const PLATFORM = { youtube: 'YouTube', facebook: 'Facebook', instagram: 'Instagram', tiktok: 'TikTok', x: 'X', vimeo: 'Vimeo', file: 'File', web: 'Link', rumble: 'Rumble', snapchat: 'Snapchat' };
const IDLE_STEPS = [30, 60, 120, 180, 300, 600, 900, 1800, 3600]; // one per tick label

const state = { settings: {}, items: [], folders: [], env: {} };
const ui = { filter: 'all', search: '', sort: 'added', addMode: 'download', cards: new Map(), cardJson: new Map() };

// ===================================================================== messages from the app

function onHostMessage(m) {
  if (!m || !m.type) return;
  switch (m.type) {
    case 'state':
      state.settings = m.settings; state.items = m.items; state.folders = m.folders; state.env = m.env;
      renderAll();
      break;
    case 'item': {
      const i = state.items.findIndex((x) => x.id === m.item.id);
      if (i < 0) break; // removed meanwhile; the next full state is authoritative
      state.items[i] = m.item;
      renderGrid();
      break;
    }
    case 'status':
      setStatus(m.text, m.kind);
      break;
    case 'toast':
      toast(m.text, m.kind);
      break;
    case 'section':
      go(m.section);
      break;
  }
}
if (wv) wv.addEventListener('message', (e) => onHostMessage(e.data));

// ===================================================================== navigation

function go(section) {
  if (!section || !$(`section[data-section="${section}"]`)) section = 'videos';
  $$('section').forEach((s) => s.classList.toggle('active', s.dataset.section === section));
  $$('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.section === section));
  if (location.hash !== '#' + section) history.replaceState(null, '', '#' + section);
  $('#content').scrollTop = 0;
}
$$('#nav a').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); go(a.dataset.section); }));
go(location.hash.slice(1) || 'videos');

// ===================================================================== settings bindings

function setSetting(key, value) {
  state.settings[key] = value;
  host.post({ type: 'set', key, value });
}

function bindSettings() {
  $$('[data-set]').forEach((el) => {
    const key = el.dataset.set;
    const isInt = el.dataset.type === 'int' || el.type === 'range';
    const read = () => el.type === 'checkbox' ? el.checked : isInt ? parseInt(el.value, 10) : el.value;
    if (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && el.type === 'text') || (el.tagName === 'INPUT' && !el.type)) {
      let t = 0;
      el.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => setSetting(key, read()), 700); });
      el.addEventListener('change', () => { clearTimeout(t); setSetting(key, read()); });
    } else if (el.type === 'range') {
      el.addEventListener('input', () => { if (key === 'volume') $('#vol-label').textContent = el.value + '%'; });
      el.addEventListener('change', () => setSetting(key, read()));
    } else {
      el.addEventListener('change', () => setSetting(key, read()));
    }
  });

  const idle = $('#idle-range');
  idle.addEventListener('input', () => { $('#idle-label').textContent = fmtIdle(IDLE_STEPS[+idle.value]); });
  idle.addEventListener('change', () => setSetting('idleSeconds', IDLE_STEPS[+idle.value]));

  const quotes = $('#quotes');
  let qt = 0;
  const sendQuotes = () => setSetting('quotes', quotes.value.split('\n').map((s) => s.trim()).filter(Boolean));
  quotes.addEventListener('input', () => { clearTimeout(qt); qt = setTimeout(sendQuotes, 900); });
  quotes.addEventListener('change', () => { clearTimeout(qt); sendQuotes(); });
}

function fillSettings() {
  const s = state.settings;
  $$('[data-set]').forEach((el) => {
    if (document.activeElement === el) return;
    const v = s[el.dataset.set];
    if (v === undefined) return;
    if (el.type === 'checkbox') el.checked = !!v;
    else if (el.tagName === 'SELECT') {
      el.value = String(v);
      if (el.value !== String(v)) { // keep unusual values selectable
        const o = document.createElement('option'); o.value = String(v); o.textContent = String(v); el.appendChild(o); el.value = String(v);
      }
    } else el.value = v ?? '';
  });
  $('#vol-label').textContent = (s.volume ?? 70) + '%';
  const idle = $('#idle-range');
  if (document.activeElement !== idle) {
    let best = 0;
    IDLE_STEPS.forEach((v, i) => { if (Math.abs(v - s.idleSeconds) < Math.abs(IDLE_STEPS[best] - s.idleSeconds)) best = i; });
    idle.value = best;
    $('#idle-label').textContent = fmtIdle(s.idleSeconds);
  }
  const q = $('#quotes');
  if (document.activeElement !== q) q.value = (s.quotes || []).join('\n');
  $$('.hk').forEach((e) => (e.textContent = s.hotkey || 'Ctrl+Alt+M'));
  if (!ui.listening) $('#hotkey-text').textContent = s.hotkey || 'Ctrl+Alt+M';
}

// ===================================================================== render: everything

function renderAll() {
  fillSettings();
  renderEnv();
  renderGrid();
  renderFolders();
  renderAccounts();
}

function renderEnv() {
  const e = state.env, s = state.settings;
  setStatus(e.status, e.statusKind);
  $('#app-version').textContent = 'v' + (e.version || '');
  $('#stat-watch').textContent = fmtWatch(e.watchMinutes || 0);

  // when it starts
  const ac = e.windowsScreenOffAc, dc = e.windowsScreenOffDc;
  const fmtW = (v) => v == null ? 'unknown' : v === 0 ? 'never' : fmtIdle(v);
  $('#win-timeout').innerHTML =
    `Windows turns the screen off after: <b>${fmtW(ac)}</b> plugged in · <b>${fmtW(dc)}</b> on battery` +
    (e.effectiveThresholdMs && e.effectiveThresholdMs < s.idleSeconds * 1000
      ? `. That's sooner than your setting, so videos start after <b>${fmtIdle(Math.round(e.effectiveThresholdMs / 1000))}</b>.`
      : '. Videos start before that happens.');
  const paused = s.pausedUntil > Date.now();
  $('#resume-btn').classList.toggle('hidden', !paused);

  // downloads
  $('#videos-folder').textContent = e.videosFolder || '';
  $('#disk-line').textContent = e.freeBytes >= 0 ? `${fmtBytes(e.freeBytes)} free on this drive · your library uses ${fmtBytes(e.librarySize || 0)}` : '';
  const y = e.ytdlp || {};
  $('#ytdlp-version').textContent = y.version || (y.busy ? 'installing…' : y.path ? 'found' : 'not installed yet');
  $('#ytdlp-line').textContent = y.busy ? 'Working…' :
    y.managed ? 'The app\'s own copy (kept up to date automatically).' :
    y.path ? 'Using the copy found on this PC. The app installs its own up-to-date copy the first time you add a link.' :
    'Installed automatically the first time you add a link.';
  $('#update-tools').disabled = !!y.busy;
  $('#helpers-line').innerHTML = [
    e.ffmpeg ? '✓ ffmpeg (merging HD video, converting, thumbnails)' : '✗ ffmpeg missing — downloads limited to lower quality; install with <span class="mono">winget install Gyan.FFmpeg</span>',
    e.js ? `✓ ${e.js} (needed for YouTube)` : '✗ No JavaScript runtime — YouTube downloads may fail; install with <span class="mono">winget install DenoLand.Deno</span>',
  ].join('<br>');
  $('#dl-hint').textContent = e.freeBytes >= 0 ? `Saves to ${shortPath(e.videosFolder)} · ${fmtBytes(e.freeBytes)} free` : '';

  // app
  const he = $('#hotkey-error');
  he.textContent = e.hotkeyError || '';
  he.classList.toggle('hidden', !e.hotkeyError);
  $('#startup-sub').innerHTML = e.startupDisabledByWindows && s.startWithWindows
    ? '<span class="error-text">Windows has this app turned off in Task Manager › Startup apps. Turn the switch off and on again to re-enable it.</span>'
    : 'Runs quietly in the tray (about 20 MB of memory while waiting; nothing extra until videos play).';
}

let lastStatus = '';
function setStatus(text, kind) {
  if (!text) return;
  const pill = $('#status-pill');
  pill.className = 'pill ' + (kind || '');
  if (text !== lastStatus) { $('#status-text').textContent = text; $('#status-long').textContent = text; lastStatus = text; }
}

// ===================================================================== render: library grid

function visibleItems() {
  const q = ui.search.trim().toLowerCase();
  let list = state.items.filter((it) => {
    switch (ui.filter) {
      case 'files': if (it.kind !== 'file') return false; break;
      case 'links': if (it.kind !== 'link') return false; break;
      case 'busy': if (!['queued', 'downloading', 'converting'].includes(it.status) && !it.needsConvert) return false; break;
      case 'problems': if (!['error', 'missing'].includes(it.status)) return false; break;
      case 'off': if (it.enabled) return false; break;
    }
    if (q && !((it.title || '') + ' ' + (it.url || '') + ' ' + (it.path || '')).toLowerCase().includes(q)) return false;
    return true;
  });
  const by = {
    added: (a, b) => b.addedAt - a.addedAt,
    title: (a, b) => (a.title || '').localeCompare(b.title || ''),
    played: (a, b) => b.playCount - a.playCount || b.addedAt - a.addedAt,
    length: (a, b) => b.duration - a.duration,
  }[ui.sort];
  return list.sort(by);
}

function renderGrid() {
  const grid = $('#grid');
  const list = visibleItems();
  const all = state.items;
  $('#nav-count').textContent = all.length || '';
  $('#stat-videos').textContent = all.filter((i) => i.playable).length;
  $('#empty-lib').classList.toggle('hidden', all.length > 0);
  const counts = {
    all: all.length, files: all.filter((i) => i.kind === 'file').length, links: all.filter((i) => i.kind === 'link').length,
    busy: all.filter((i) => ['queued', 'downloading', 'converting'].includes(i.status) || i.needsConvert).length,
    problems: all.filter((i) => ['error', 'missing'].includes(i.status)).length, off: all.filter((i) => !i.enabled).length,
  };
  $$('#filters .chip').forEach((c) => {
    const n = counts[c.dataset.filter];
    const label = c.dataset.label || (c.dataset.label = c.textContent);
    c.innerHTML = label + (n ? `<span class="n">${n}</span>` : '');
    if (c.dataset.filter !== 'all') c.classList.toggle('hidden', !n && ui.filter !== c.dataset.filter);
  });

  const seen = new Set();
  let prevEl = null;
  for (const it of list) {
    seen.add(it.id);
    const json = JSON.stringify(it);
    let el = ui.cards.get(it.id);
    if (!el) {
      el = document.createElement('div');
      el.className = 'vcard';
      el.dataset.id = it.id;
      ui.cards.set(it.id, el);
    }
    if (ui.cardJson.get(it.id) !== json) {
      el.innerHTML = cardHtml(it);
      el.classList.toggle('off', !it.enabled);
      ui.cardJson.set(it.id, json);
    }
    const want = prevEl ? prevEl.nextSibling : grid.firstChild;
    if (want !== el) grid.insertBefore(el, want);
    prevEl = el;
  }
  for (const [id, el] of ui.cards) {
    if (!seen.has(id)) { el.remove(); if (!state.items.some((i) => i.id === id)) { ui.cards.delete(id); ui.cardJson.delete(id); } }
  }
}

function cardHtml(it) {
  const tall = it.height > it.width && it.width > 0;
  const thumb = it.thumb
    ? `<div class="bg" style="background-image:url('${attr(it.thumb)}')"></div><img src="${attr(it.thumb)}" alt="" loading="lazy" onerror="this.remove()">`
    : `<div class="ph">${it.kind === 'link' ? '🔗' : '🎬'}</div>`;
  const plat = PLATFORM[it.platform] || 'Video';
  let overlay = '';
  if (it.status === 'downloading' || it.status === 'converting') {
    const label = it.status === 'converting' ? 'Converting' : 'Downloading';
    overlay = `<div class="state"><div>${label} ${it.progress ? Math.floor(it.progress) + '%' : '…'}</div><div class="bar"><i style="width:${it.progress || 2}%"></i></div></div>`;
  } else if (it.status === 'queued') {
    overlay = `<div class="state"><div class="spin"></div><div>Waiting to download…</div></div>`;
  } else if (it.needsConvert && it.status === 'ready') {
    overlay = `<div class="state"><div class="spin"></div><div>Preparing (converting)…</div></div>`;
  } else if (it.status === 'error' || it.status === 'missing') {
    const msg = it.status === 'missing' ? 'File not found. Was it moved or deleted?' : (it.error || 'Something went wrong.');
    overlay = `<div class="state err"><div>${esc(msg)}</div></div>`;
  }
  const online = it.status === 'online' ? '<span class="badge-tr">ONLINE</span>' : '';
  const dur = it.duration > 0 ? `<span class="badge-br">${fmtDur(it.trimEnd > 0 ? it.trimEnd - it.trimStart : it.duration - (it.trimStart || 0))}${it.trimStart || it.trimEnd ? ' ✂' : ''}</span>` : '';
  const resume = it.resumeAt > 0 && it.duration > 0 ? `<div class="resume" style="width:${Math.min(100, it.resumeAt / it.duration * 100)}%"></div>` : '';
  const meta = [plat];
  if (it.size > 0) meta.push(fmtBytes(it.size));
  if (it.width > 0) meta.push(tall ? 'vertical' : (it.height >= 1080 ? '1080p+' : it.height + 'p'));
  if (it.playCount > 0) meta.push(`played ${it.playCount}×`);
  const canPlay = it.playable;
  return `
    <div class="thumb ${tall ? 'tall' : ''}" data-act="${canPlay ? 'play' : 'menu'}" title="${canPlay ? 'Play this now' : ''}">
      ${thumb}
      <span class="badge-tl p-${attr(it.platform)}">${esc(plat)}</span>${online}${dur}${resume}
      ${canPlay && !overlay ? '<div class="play"><i><svg viewBox="0 0 24 24"><path d="M7 4.5v15L19.5 12z"/></svg></i></div>' : ''}
      ${overlay}
    </div>
    <div class="vbody">
      <div class="vtitle" title="${attr(it.title)}">${esc(it.title || 'Untitled')}</div>
      <div class="vmeta">${esc(meta.join(' · '))}</div>
      <div class="vactions">
        <label class="switch" title="Include in rotation"><input type="checkbox" data-act="toggle" ${it.enabled ? 'checked' : ''}><span></span></label>
        <span class="lbl">${it.enabled ? 'In rotation' : 'Off'}</span>
        ${it.status === 'error' || it.status === 'missing' ? '<button class="icon-btn" data-act="retry" title="Retry"><svg viewBox="0 0 24 24"><path d="M12 5V2L8 6l4 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z"/></svg></button>' : ''}
        <button class="icon-btn" data-act="trim" title="Rename / play only part"><svg viewBox="0 0 24 24"><path d="M9.6 7.6A3 3 0 1 0 8 9.2L10.6 12 8 14.8a3 3 0 1 0 1.6 1.6L12 14l7 7h3L9.6 7.6zM6 8a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm0 10a1 1 0 1 1 0-2 1 1 0 0 1 0 2zM19 3l-6 6 1.5 1.5L22 3z"/></svg></button>
        <button class="icon-btn" data-act="menu" title="More"><svg viewBox="0 0 24 24"><path d="M6 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm6 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm6 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/></svg></button>
      </div>
    </div>`;
}

$('#grid').addEventListener('click', (e) => {
  const card = e.target.closest('.vcard');
  if (!card) return;
  const it = state.items.find((x) => x.id === card.dataset.id);
  const actEl = e.target.closest('[data-act]');
  if (!it || !actEl) return;
  const act = actEl.dataset.act;
  if (act === 'toggle') return; // handled by change
  e.preventDefault();
  if (act === 'play') host.post({ type: 'play', id: it.id });
  else if (act === 'retry') host.post({ type: 'item.retry', id: it.id });
  else if (act === 'trim') openTrim(it);
  else if (act === 'menu') openMenu(it, actEl);
});
$('#grid').addEventListener('change', (e) => {
  if (e.target.dataset.act !== 'toggle') return;
  const id = e.target.closest('.vcard').dataset.id;
  host.post({ type: 'item.toggle', id, enabled: e.target.checked });
});

// ===================================================================== item menu & dialogs

function openMenu(it, anchor) {
  closeMenu();
  const m = document.createElement('div');
  m.className = 'menu';
  const add = (label, fn, cls = '') => {
    const b = document.createElement('button'); b.textContent = label; if (cls) b.className = cls;
    b.onclick = () => { closeMenu(); fn(); }; m.appendChild(b);
  };
  const hr = () => m.appendChild(document.createElement('hr'));
  if (it.playable) add('▶  Play this now', () => host.post({ type: 'play', id: it.id }));
  add('✂  Rename / play only part…', () => openTrim(it));
  if (it.path) add('📂  Show the file', () => host.post({ type: 'item.reveal', id: it.id }));
  if (it.url) add('🌐  Open the link', () => host.post({ type: 'openUrl', url: it.url }));
  if (it.youtube && it.status !== 'online') add('☁  Stream online instead (no disk space)', () => host.post({ type: 'item.stream', id: it.id }));
  if (it.kind === 'link' && it.status === 'online') add('⬇  Download it instead', () => host.post({ type: 'item.download', id: it.id }));
  if (it.status === 'error' || it.status === 'missing') add('↻  Retry', () => host.post({ type: 'item.retry', id: it.id }));
  if (it.path && !it.converted && it.status === 'ready') add('🛠  Convert (if it won\'t play)', () => host.post({ type: 'item.convert', id: it.id }));
  hr();
  add('🗑  Remove…', () => openRemove(it), 'danger');
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect();
  const w = m.offsetWidth, h = m.offsetHeight;
  m.style.left = Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w)) + 'px';
  m.style.top = (r.bottom + h + 8 < window.innerHeight ? r.bottom + 6 : r.top - h - 6) + 'px';
  setTimeout(() => document.addEventListener('mousedown', menuAway), 0);
}
function menuAway(e) { if (!e.target.closest('.menu')) closeMenu(); }
function closeMenu() { $$('.menu').forEach((m) => m.remove()); document.removeEventListener('mousedown', menuAway); }

function modal(title, bodyHtml, actions) {
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = bodyHtml;
  const box = $('#modal-actions');
  box.innerHTML = '';
  actions.forEach((a) => {
    const b = document.createElement('button');
    b.className = 'btn ' + (a.cls || '');
    b.textContent = a.label;
    b.onclick = () => { if (a.fn && a.fn() === false) return; closeModal(); };
    box.appendChild(b);
  });
  $('#modal').classList.remove('hidden');
  const first = $('#modal-body input, #modal-body textarea');
  if (first) setTimeout(() => first.focus(), 30);
}
function closeModal() { $('#modal').classList.add('hidden'); }
$('#modal').addEventListener('mousedown', (e) => { if (e.target.id === 'modal') closeModal(); });

function openTrim(it) {
  modal('Rename / play only part', `
    <label class="field"><span>Title</span><input id="m-title" value="${attr(it.title)}"></label>
    <div class="trim-row">
      <label class="field"><span>Start at (m:ss)</span><input id="m-from" class="time" style="width:100%" value="${it.trimStart ? fmtDur(it.trimStart) : ''}" placeholder="0:00"></label>
      <label class="field"><span>Stop at (m:ss)</span><input id="m-to" class="time" style="width:100%" value="${it.trimEnd ? fmtDur(it.trimEnd) : ''}" placeholder="${it.duration ? fmtDur(it.duration) : 'end'}"></label>
    </div>
    <div class="small">Great for long streams: keep just the part that fires you up. Leave empty to play the whole video.</div>`,
  [
    { label: 'Cancel', cls: 'ghost' },
    {
      label: 'Save', cls: 'primary', fn: () => {
        const from = parseTime($('#m-from').value), to = parseTime($('#m-to').value);
        if (from == null || to == null) { toast('Use times like 1:30 or 1:02:30', 'error'); return false; }
        if (to > 0 && to <= from) { toast('"Stop at" must be after "Start at"', 'error'); return false; }
        host.post({ type: 'item.update', id: it.id, title: $('#m-title').value, trimStart: from, trimEnd: to });
      },
    },
  ]);
}

function openRemove(it) {
  const downloaded = it.kind === 'link' && it.path;
  const inFolder = it.kind === 'file' && it.folderId;
  let body = `<div>Remove <b style="color:var(--text)">${esc(it.title)}</b> from your videos?</div>`;
  if (downloaded) body += `<label class="check"><input type="checkbox" id="m-del" checked><span>Also move the downloaded file to the Recycle Bin (frees ${fmtBytes(it.size)})</span></label>
      <div class="small">If you keep the file, it stays in your videos folder and shows here turned off.</div>`;
  else if (inFolder) body += `<div class="small">This file is in a watched folder, so it would come back. Choose:</div>
      <label class="check"><input type="checkbox" id="m-del"><span>Move the file to the Recycle Bin (otherwise it's just turned off)</span></label>`;
  else if (it.path) body += `<div class="small">Your file stays where it is on disk.</div>`;
  modal('Remove video', body, [
    { label: 'Cancel', cls: 'ghost' },
    { label: 'Remove', cls: 'primary', fn: () => host.post({ type: 'item.remove', id: it.id, deleteFile: !!($('#m-del') && $('#m-del').checked) }) },
  ]);
}

// ===================================================================== folders & accounts

function renderFolders() {
  const box = $('#folders');
  box.innerHTML = state.folders.map((f) => `
    <div class="folder">
      <span>📁</span>
      <span class="fp mono" title="${attr(f.path)}">${esc(f.path)}${f.exists ? '' : ' <span class="error-text">(not found)</span>'}</span>
      <span class="fc">${f.count} video${f.count === 1 ? '' : 's'}${f.isDefault ? ' · downloads go here' : ''}</span>
      ${f.isDefault ? '<button class="btn small ghost" data-action="openVideos">Open</button>' :
        `<button class="btn small ghost" data-remove-folder="${attr(f.id)}">Stop watching</button>`}
    </div>`).join('');
}
$('#folders').addEventListener('click', (e) => {
  const b = e.target.closest('[data-remove-folder]');
  if (b) host.post({ type: 'removeFolder', id: b.dataset.removeFolder });
});

function renderAccounts() {
  const acc = state.env.accounts || {};
  const sites = state.env.sites || [];
  $('#accounts').innerHTML = sites.map((s) => `
    <div class="acct">
      <span class="an">${esc(s.name)}</span>
      <span class="as ${acc[s.key] ? 'on' : ''}">${acc[s.key] ? '✓ Signed in' : 'Not signed in'}</span>
      ${acc[s.key]
        ? `<button class="btn small ghost" data-signout="${attr(s.key)}">Sign out</button>`
        : `<button class="btn small" data-signin="${attr(s.key)}">Sign in…</button>`}
    </div>`).join('');
}
$('#accounts').addEventListener('click', (e) => {
  const a = e.target.closest('[data-signin]'), b = e.target.closest('[data-signout]');
  if (a) host.post({ type: 'account.signin', site: a.dataset.signin });
  if (b) host.post({ type: 'account.signout', site: b.dataset.signout });
});

// ===================================================================== add links / files

$$('#add-mode button').forEach((b) => b.addEventListener('click', () => {
  ui.addMode = b.dataset.mode;
  $$('#add-mode button').forEach((x) => x.classList.toggle('on', x === b));
}));
$('#part-toggle').addEventListener('change', (e) => $('#part-fields').classList.toggle('hidden', !e.target.checked));

function addUrl() {
  const input = $('#url');
  const url = input.value.trim();
  if (!url) { input.focus(); return; }
  let start = 0, end = 0;
  if ($('#part-toggle').checked) {
    start = parseTime($('#part-from').value); end = parseTime($('#part-to').value);
    if (start == null || end == null || end <= start) { toast('For "only part of it", enter times like 12:30 → 18:00', 'error'); return; }
  }
  host.post({ type: 'addUrl', url, stream: ui.addMode === 'stream', start, end });
  input.value = '';
  $('#part-toggle').checked = false; $('#part-fields').classList.add('hidden');
  $('#part-from').value = ''; $('#part-to').value = '';
}
$('#add-url').addEventListener('click', addUrl);
$('#url').addEventListener('keydown', (e) => { if (e.key === 'Enter') addUrl(); });
$('#url').addEventListener('paste', () => setTimeout(() => {
  // pasting a single link adds it immediately — fewer clicks
  const v = $('#url').value.trim();
  if (/^https?:\/\/\S+$/i.test(v) && !$('#part-toggle').checked) addUrl();
}, 30));

// global buttons
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-action]');
  if (!b) return;
  e.preventDefault();
  const a = b.dataset.action;
  const map = {
    play: { type: 'play' }, preview: { type: 'preview' }, pickFiles: { type: 'pickFiles' }, pickFolder: { type: 'pickFolder' },
    openVideos: { type: 'openFolder', which: 'videos' }, openData: { type: 'openFolder', which: 'data' }, openLogs: { type: 'openFolder', which: 'logs' },
    changeVideosFolder: { type: 'changeVideosFolder' }, updateTools: { type: 'tools.update' }, resetQuotes: { type: 'resetQuotes' },
  };
  if (a === 'uninstall') {
    modal('Uninstall Motivation Screen?', '<div>The app, its shortcuts and its start-with-Windows entry will be removed. Your videos are not deleted.</div>', [
      { label: 'Cancel', cls: 'ghost' }, { label: 'Uninstall', cls: 'primary', fn: () => host.post({ type: 'uninstall' }) },
    ]);
    return;
  }
  if (map[a]) host.post(map[a]);
});
$$('[data-pause]').forEach((b) => b.addEventListener('click', () => host.post({ type: 'pause', minutes: +b.dataset.pause })));

// filters / search / sort
$('#filters').addEventListener('click', (e) => {
  const c = e.target.closest('.chip'); if (!c) return;
  ui.filter = c.dataset.filter;
  $$('#filters .chip').forEach((x) => x.classList.toggle('on', x === c));
  renderGrid();
});
$('#search').addEventListener('input', (e) => { ui.search = e.target.value; renderGrid(); });
$('#sort').addEventListener('change', (e) => { ui.sort = e.target.value; renderGrid(); });

// ===================================================================== drag & drop

let dragDepth = 0;
document.addEventListener('dragenter', (e) => { e.preventDefault(); dragDepth++; $('#drop').classList.remove('hidden'); });
document.addEventListener('dragleave', (e) => { e.preventDefault(); if (--dragDepth <= 0) { dragDepth = 0; $('#drop').classList.add('hidden'); } });
document.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
document.addEventListener('drop', (e) => {
  e.preventDefault();
  dragDepth = 0;
  $('#drop').classList.add('hidden');
  const files = e.dataTransfer.files;
  if (files && files.length) host.postFiles({ type: 'drop' }, files);
  else {
    const text = e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain');
    if (text) host.post({ type: 'drop', text: text.split('\n')[0].trim() });
  }
});

// ===================================================================== hotkey capture

$('#hotkey').addEventListener('click', () => {
  ui.listening = true;
  $('#hotkey').classList.add('listening');
  $('#hotkey-text').textContent = 'Press the new shortcut…';
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { closeMenu(); if (!$('#modal').classList.contains('hidden')) closeModal(); }
  if (!ui.listening) return;
  e.preventDefault();
  if (['Control', 'Alt', 'Shift', 'Meta'].includes(e.key)) return;
  if (e.key === 'Escape') { stopListening(); return; }
  const mods = [];
  if (e.ctrlKey) mods.push('Ctrl');
  if (e.altKey) mods.push('Alt');
  if (e.shiftKey) mods.push('Shift');
  if (e.metaKey) mods.push('Win');
  const key = keyName(e.code);
  if (!key) { toast('That key can\'t be used. Try a letter, number or F-key.', 'error'); return; }
  if (!mods.length && !/^F\d+$/.test(key) && key !== 'Pause') { toast('Add Ctrl, Alt or Shift (e.g. Ctrl+Alt+M)', 'error'); return; }
  const combo = [...mods, key].join('+');
  stopListening(combo);
  setSetting('hotkey', combo);
}, true);
function stopListening(text) {
  ui.listening = false;
  $('#hotkey').classList.remove('listening');
  $('#hotkey-text').textContent = text || state.settings.hotkey || 'Ctrl+Alt+M';
}
function keyName(code) {
  let m;
  if ((m = /^Key([A-Z])$/.exec(code))) return m[1];
  if ((m = /^Digit(\d)$/.exec(code))) return m[1];
  if (/^F\d{1,2}$/.test(code)) return code;
  const map = { Space: 'Space', Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Backslash: '\\',
    Home: 'Home', End: 'End', PageUp: 'PageUp', PageDown: 'PageDown', Insert: 'Insert', Delete: 'Delete', Pause: 'Pause',
    ArrowUp: 'Up', ArrowDown: 'Down', ArrowLeft: 'Left', ArrowRight: 'Right' };
  if ((m = /^Numpad(\d)$/.exec(code))) return 'NumPad' + m[1];
  return map[code] || null;
}

// ===================================================================== toasts

function toast(text, kind = 'info') {
  const t = document.createElement('div');
  t.className = 'toast ' + kind;
  const span = document.createElement('span');
  span.textContent = text;
  t.appendChild(span);
  $('#toasts').appendChild(t);
  setTimeout(() => { t.style.transition = 'opacity .3s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, kind === 'error' ? 6500 : 3500);
}

// ===================================================================== formatting helpers

function esc(s) { return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function attr(s) { return esc(s); }
function fmtDur(sec) {
  sec = Math.max(0, Math.round(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}
function fmtIdle(sec) {
  if (sec < 60) return sec + ' s';
  if (sec < 3600) { const m = sec / 60; return (Number.isInteger(m) ? m : m.toFixed(1)) + ' min'; }
  const h = sec / 3600; return (Number.isInteger(h) ? h : h.toFixed(1)) + ' h';
}
function fmtWatch(min) { return min >= 60 ? Math.floor(min / 60) + 'h ' + (min % 60) + 'm' : min + 'm'; }
function fmtBytes(b) {
  if (!(b >= 0)) return '?';
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return (i >= 3 ? b.toFixed(1) : Math.round(b)) + ' ' + u[i];
}
function shortPath(p) { if (!p) return ''; return p.length > 38 ? p.slice(0, 3) + '…' + p.slice(-32) : p; }
/** "1:02:03" / "12:30" / "90" → seconds; "" → 0; invalid → null */
function parseTime(s) {
  s = (s || '').trim();
  if (!s) return 0;
  if (!/^\d+(:\d{1,2}){0,2}$/.test(s)) return null;
  return s.split(':').map(Number).reduce((acc, v) => acc * 60 + v, 0);
}

/* --------------------------------------------------------------------- browser preview (outside the app) */
const Mock = {
  handle(msg) {
    if (msg.type === 'ready') setTimeout(() => onHostMessage(Mock.state()), 50);
    else if (msg.type === 'set') { /* ignore */ }
    else toast('(preview) ' + msg.type);
  },
  state() {
    const now = Date.now();
    const mk = (o) => Object.assign({ kind: 'link', status: 'ready', enabled: true, progress: 0, playCount: 0, size: 0, width: 1280, height: 720, duration: 0, addedAt: now, playable: true, trimStart: 0, trimEnd: 0, resumeAt: 0 }, o);
    return {
      type: 'state',
      settings: { autoStart: true, idleSeconds: 180, beatWindowsScreenOff: true, skipWhenFullscreen: true, skipWhenSoundPlaying: true, volume: 70, idleSound: false, manualSound: true, shuffle: true, resumeLongVideos: true, closeOnAnyInput: true, screenOffAfterMinutes: 60, showClock: true, showTitle: true, showGoal: true, goalTitle: 'WHY I GRIND', goalText: '$10k/month trading. Freedom.', quotes: ['Discipline is doing it when you don\'t feel like it.'], quoteEveryMinutes: 3, hotkey: 'Ctrl+Alt+M', startWithWindows: true, showTips: true, maxHeight: 720, maxFileGb: 3, keepFreeGb: 5, playlistLimit: 30, quietStart: '23:00', quietEnd: '07:00', quietMode: 'mute' },
      items: [
        mk({ id: 'a', title: 'TJR — The mindset that changed my trading forever', platform: 'youtube', duration: 1834, size: 412e6, playCount: 3, resumeAt: 600, youtube: true }),
        mk({ id: 'b', title: 'Discipline reel', platform: 'instagram', status: 'downloading', progress: 46, playable: false }),
        mk({ id: 'c', title: 'MambaFX — why most traders fail', platform: 'facebook', duration: 59, width: 720, height: 1280, size: 9e6 }),
        mk({ id: 'd', title: 'facebook.com/reel/12345', platform: 'facebook', status: 'error', error: 'Facebook wants you to be signed in. Sign in under Settings → Accounts, then press Retry.', playable: false }),
        mk({ id: 'e', kind: 'file', title: 'my_morning_routine', platform: 'file', duration: 312, size: 88e6, enabled: false, folderId: 'f1', path: 'D:\\Motivation Videos\\my_morning_routine.mp4' }),
        mk({ id: 'f', title: 'Andrew — escape the matrix (stream)', platform: 'youtube', status: 'online', duration: 0, youtube: true }),
      ],
      folders: [{ id: 'f1', path: 'D:\\Motivation Videos', isDefault: true, exists: true, count: 1 }],
      env: { version: '1.0.0', status: 'Starts after 3:00 idle (idle 0:12)', statusKind: 'wait', videosFolder: 'D:\\Motivation Videos', freeBytes: 879e9, librarySize: 509e6, windowsScreenOffAc: 0, windowsScreenOffDc: 0, effectiveThresholdMs: 180000, ytdlp: { version: '2026.08.19', managed: true }, ffmpeg: true, js: 'Deno', accounts: { instagram: false, facebook: true }, sites: [{ key: 'instagram', name: 'Instagram' }, { key: 'facebook', name: 'Facebook' }, { key: 'tiktok', name: 'TikTok' }, { key: 'youtube', name: 'YouTube' }, { key: 'x', name: 'X (Twitter)' }], watchMinutes: 135 },
    };
  },
};

// ===================================================================== start

bindSettings();
host.post({ type: 'ready' });
