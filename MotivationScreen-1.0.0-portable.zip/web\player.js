/* Motivation Screen — fullscreen player.
   Host (C#) sends one "init" message; the page plays the list and reports progress back. */
'use strict';

const $ = (id) => document.getElementById(id);
const body = document.body;
const video = $('video');
const ambient = $('ambient');
const actx = ambient.getContext('2d', { alpha: false });

const host = {
  post(msg) { try { window.chrome.webview.postMessage(msg); } catch (e) { /* not inside the app */ } },
};

const PLATFORM = { youtube: 'YouTube', facebook: 'Facebook', instagram: 'Instagram', tiktok: 'TikTok', x: 'X', vimeo: 'Vimeo', file: 'Video', web: 'Video', rumble: 'Rumble', snapchat: 'Snapchat' };

const S = {
  cfg: null,
  items: [],
  index: -1,
  volume: 70,
  muted: true,
  playing: false,
  current: null,
  lastQuoteAt: 0,
  quoteTimer: 0,
  errorsInARow: 0,
  reportTimer: 0,
  lastReportAt: 0,
  watchedSince: 0,   // seconds of actual playback since last report
  lastTick: 0,
  fadeTimer: 0,
  ytPlayer: null,
  ytReady: null,
  ytPoll: 0,
  ambientTimer: 0,
  controlsTimer: 0,
  nowTimer: 0,
  started: false,
  inQuote: false,
  emptyTimer: 0,
};

// ------------------------------------------------------------------ boot

window.chrome?.webview?.addEventListener('message', (e) => {
  const m = e.data;
  if (m && m.type === 'init') init(m);
});
host.post({ type: 'ready' });

function init(cfg) {
  S.cfg = cfg;
  S.items = cfg.items || [];
  S.volume = clamp(cfg.volume ?? 70, 0, 100);
  S.muted = !!cfg.muted;
  body.classList.remove('booting');
  body.classList.add('mode-' + cfg.mode);
  body.classList.toggle('windowed', !!cfg.windowed);
  applyOverlaySettings();
  startClock();
  $('vol').value = S.volume;
  syncMuteUi();

  if (S.cfg.mode === 'idle' && S.cfg.closeOnInput) {
    showHint('Move the mouse or press any key to get back to work', 6000);
  } else {
    showHint(`Esc to close  ·  Space pause  ·  ← → previous / next  ·  ↑ ↓ volume  ·  M mute`, 6000);
  }

  if (!S.items.length) { startEmptyMode(); return; }
  playIndex(0);
}

function applyOverlaySettings() {
  const o = S.cfg.overlay || {};
  body.classList.toggle('hide-clock', !o.clock);
  body.classList.toggle('hide-title', !o.title);
  body.classList.toggle('show-goal', !!o.goal);
  $('goal-title').textContent = (o.goalTitle || 'WHY I GRIND').toUpperCase();
  $('goal-text').textContent = o.goalText || '';
  $('goal-countdown').innerHTML = countdownHtml(o.goalDate);
}

function countdownHtml(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  if (isNaN(d)) return '';
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const days = Math.round((d - today) / 86400000);
  if (days > 1) return `<b>${days}</b>days to go`;
  if (days === 1) return `<b>1</b>day to go`;
  if (days === 0) return `<b>Today</b>is the day`;
  return `<b>${-days}</b>days past the deadline — keep pushing`;
}

// ------------------------------------------------------------------ clock

function startClock() {
  const tick = () => {
    const now = new Date();
    $('clock-time').textContent = now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    $('clock-date').textContent = now.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' });
  };
  tick();
  setInterval(tick, 1000);
}

// ------------------------------------------------------------------ playlist

function playIndex(i, opts = {}) {
  if (!S.items.length) return;
  if (i >= S.items.length) {
    host.post({ type: 'wrapped' });
    if (S.cfg.shuffle && S.items.length > 2) reshuffleLocal();
    i = 0;
  }
  if (i < 0) i = S.items.length - 1;
  cancelQuote();
  if (S.current && !S.current._done) reportPosition(false);
  stopCurrent();
  S.index = i;
  const item = S.items[i];
  item._announced = false; // count every play, including repeats after the list wraps
  item._done = false;
  S.current = item;
  S.watchedSince = 0;
  showNow(item);
  if (item.yt && !item.src) playYouTube(item, opts);
  else playFile(item, opts);
}

function reshuffleLocal() {
  const last = S.items[S.items.length - 1];
  for (let k = S.items.length - 1; k > 0; k--) {
    const j = Math.floor(Math.random() * (k + 1));
    [S.items[k], S.items[j]] = [S.items[j], S.items[k]];
  }
  if (S.items[0] === last) [S.items[0], S.items[S.items.length - 1]] = [S.items[S.items.length - 1], S.items[0]];
}

function next() { playIndex(S.index + 1); }
function prev() {
  if (S.inQuote) { playIndex(S.index); return; } // replay the video that just ended
  const from = startPoint(S.current, true);
  if (currentTime() - from > 6) { seekTo(from); return; }
  playIndex(S.index - 1);
}

function startPoint(item, ignoreResume) {
  if (!item) return 0;
  const from = item.trimStart > 0 ? item.trimStart : 0;
  const to = item.trimEnd > 0 ? item.trimEnd : Infinity;
  if (!ignoreResume && item.resumeAt > from + 1 && item.resumeAt < to - 2) return item.resumeAt;
  return from;
}

/** The current video finished (naturally, or reached its trim end). */
function finished() {
  const item = S.current;
  if (!item || item._done) return; // pause() fires one more timeupdate; never finish twice
  item._done = true;
  reportPosition(true);
  item.resumeAt = 0;
  const o = S.cfg.overlay || {};
  const quotes = o.quotes || [];
  const due = Date.now() - S.lastQuoteAt >= (o.quoteEvery || 3) * 60000;
  if (quotes.length && due && S.items.length > 0) showQuote(() => playIndex(S.index + 1));
  else playIndex(S.index + 1);
}

// ------------------------------------------------------------------ local / downloaded files

function playFile(item, opts) {
  body.classList.remove('is-yt');
  video.muted = S.muted;
  video.volume = 0;
  video.src = item.src;
  video.load();
  const start = startPoint(item, opts.fromStart);
  const onMeta = () => {
    video.removeEventListener('loadedmetadata', onMeta);
    S.metaHandler = null;
    if (S.current !== item) return;
    if (start > 0 && start < (video.duration || Infinity) - 2) video.currentTime = start;
    host.post({ type: 'meta', id: item.id, d: finiteOr(video.duration, 0), w: video.videoWidth, h: video.videoHeight });
    setupAmbient(video.videoWidth, video.videoHeight);
    const p = video.play();
    // Only a real autoplay block mutes us; skipping to another video aborts this play() (AbortError) — ignore that.
    if (p && p.catch) p.catch((err) => {
      if (!err || err.name !== 'NotAllowedError' || S.current !== item) return;
      video.muted = true; S.muted = true; syncMuteUi(); video.play().catch(() => {});
    });
  };
  S.metaHandler = onMeta;
  video.addEventListener('loadedmetadata', onMeta);
}

video.addEventListener('playing', () => {
  if (!S.current || S.current.yt && !S.current.src) return;
  onStartedPlaying();
});
video.addEventListener('pause', () => { S.playing = false; body.classList.add('paused'); });
video.addEventListener('play', () => { body.classList.remove('paused'); });
video.addEventListener('timeupdate', () => {
  if (!S.current || body.classList.contains('is-yt')) return;
  const t = video.currentTime, d = video.duration;
  updateProgress(t, d);
  if (S.current.trimEnd > 0 && t >= S.current.trimEnd && !S.current._done) { video.pause(); finished(); }
});
video.addEventListener('ended', () => { if (!body.classList.contains('is-yt')) finished(); });
video.addEventListener('error', () => {
  if (!S.current || body.classList.contains('is-yt') || !video.getAttribute('src')) return;
  const code = video.error ? video.error.code : 0;
  onItemError(S.current, code);
});

function onStartedPlaying() {
  S.playing = true;
  S.errorsInARow = 0;
  body.classList.remove('paused');
  if (!S.started) { S.started = true; body.classList.add('started'); }
  if (S.current && !S.current._announced) {
    S.current._announced = true;
    host.post({ type: 'playing', id: S.current.id });
  }
  fadeInVolume();
}

function onItemError(item, code) {
  host.post({ type: 'error', id: item.id, code });
  S.errorsInARow++;
  if (S.errorsInARow >= S.items.length) {
    stopCurrent();
    startEmptyMode('None of your videos could be played right now. They\'ll be fixed in the background — check Settings.');
    return;
  }
  setTimeout(() => playIndex(S.index + 1), 700);
}

function stopCurrent() {
  if (S.metaHandler) { video.removeEventListener('loadedmetadata', S.metaHandler); S.metaHandler = null; }
  clearInterval(S.ytPoll);
  clearInterval(S.ambientTimer);
  clearInterval(S.fadeTimer);
  body.classList.remove('ambient');
  if (video.getAttribute('src')) {
    video.pause();
    video.removeAttribute('src');
    video.load(); // release the decoder + file (avoid memory growth over hours)
  }
  if (S.ytPlayer) { try { S.ytPlayer.stopVideo(); } catch (e) {} }
  updateProgress(0, 1);
}

/** Fill the sides of vertical reels with a blurred, dimmed copy of the video. */
function setupAmbient(w, h) {
  clearInterval(S.ambientTimer);
  if (!w || !h) return;
  const screenRatio = window.innerWidth / window.innerHeight;
  const ratio = w / h;
  if (Math.abs(ratio - screenRatio) / screenRatio < 0.12) { body.classList.remove('ambient'); return; }
  const draw = () => { try { actx.drawImage(video, 0, 0, ambient.width, ambient.height); } catch (e) {} };
  draw();
  body.classList.add('ambient');
  S.ambientTimer = setInterval(draw, 250);
}

// ------------------------------------------------------------------ YouTube (stream online)

function loadYouTubeApi() {
  if (S.ytReady) return S.ytReady;
  S.ytReady = new Promise((resolve, reject) => {
    window.onYouTubeIframeAPIReady = () => resolve();
    const s = document.createElement('script');
    s.src = 'https://www.youtube.com/iframe_api';
    s.onerror = () => reject(new Error('YouTube could not be reached'));
    document.head.appendChild(s);
    setTimeout(() => reject(new Error('YouTube timeout')), 20000);
  });
  return S.ytReady;
}

async function playYouTube(item, opts) {
  body.classList.add('is-yt');
  body.classList.remove('ambient');
  try { await loadYouTubeApi(); }
  catch (e) { S.ytReady = null; onItemError(item, -1); return; }
  if (S.current !== item) return;
  const start = Math.floor(startPoint(item, opts.fromStart));
  const vars = { autoplay: 1, controls: 0, disablekb: 1, fs: 0, iv_load_policy: 3, rel: 0, playsinline: 1, modestbranding: 1, start, mute: S.muted ? 1 : 0 };
  if (item.trimEnd > 0) vars.end = Math.ceil(item.trimEnd);
  const onState = (e) => {
    if (S.current !== item) return;
    if (e.data === 1) { onStartedPlaying(); body.classList.remove('paused'); }
    else if (e.data === 2) { S.playing = false; body.classList.add('paused'); }
    else if (e.data === 0) finished();
  };
  const onError = (e) => { if (S.current === item) onItemError(item, 1000 + (e.data || 0)); };
  S.onYtState = onState; S.onYtError = onError; // route events to whichever item is current
  const load = () => {
    S.ytPlayer.loadVideoById({ videoId: item.yt, startSeconds: start, endSeconds: item.trimEnd > 0 ? item.trimEnd : undefined });
    applyYtVolume(true);
  };
  if (S.ytPlayer) load();
  else if (S.ytCreating) {          // another video is creating the player right now
    await S.ytCreating;
    if (S.current !== item) return;
    load();
  } else {
    S.ytCreating = new Promise((resolve) => {
      const p = new YT.Player('yt', {
        videoId: item.yt, playerVars: vars,
        events: { onReady: () => resolve(p), onStateChange: (e) => S.onYtState && S.onYtState(e), onError: (e) => S.onYtError && S.onYtError(e) },
      });
    });
    S.ytPlayer = await S.ytCreating;
    if (S.current !== item) { try { S.ytPlayer.stopVideo(); } catch (e) {} return; }
    applyYtVolume(true);
    S.ytPlayer.playVideo();
  }
  clearInterval(S.ytPoll);
  S.ytPoll = setInterval(() => {
    if (S.current !== item || !S.ytPlayer || !S.ytPlayer.getCurrentTime) return;
    updateProgress(S.ytPlayer.getCurrentTime(), S.ytPlayer.getDuration());
  }, 500);
}

function applyYtVolume(startQuiet) {
  const p = S.ytPlayer; if (!p || !p.setVolume) return;
  if (S.muted) p.mute(); else p.unMute();
  p.setVolume(startQuiet ? Math.round(S.volume * 0.3) : S.volume);
}

// ------------------------------------------------------------------ time helpers

function isYt() { return body.classList.contains('is-yt'); }
function currentTime() {
  if (isYt()) { try { return S.ytPlayer.getCurrentTime() || 0; } catch (e) { return 0; } }
  return video.currentTime || 0;
}
function duration() {
  if (isYt()) { try { return S.ytPlayer.getDuration() || 0; } catch (e) { return 0; } }
  return finiteOr(video.duration, 0);
}
function seekTo(t) {
  t = Math.max(0, t);
  if (isYt()) { try { S.ytPlayer.seekTo(t, true); } catch (e) {} }
  else if (isFinite(video.duration)) video.currentTime = Math.min(t, video.duration - 0.5);
}
function seekBy(dt) { seekTo(currentTime() + dt); toast((dt > 0 ? '+' : '−') + Math.abs(dt) + ' s'); }
function togglePause() {
  if (isYt()) {
    try { (S.ytPlayer.getPlayerState() === 1) ? S.ytPlayer.pauseVideo() : S.ytPlayer.playVideo(); } catch (e) {}
  } else if (video.paused) video.play().catch(() => {}); else video.pause();
}

function updateProgress(t, d) {
  const pct = d > 0 && isFinite(d) ? Math.min(100, (t / d) * 100) : 0;
  $('progress-bar').style.width = pct + '%';
  // count real watch time
  const now = performance.now();
  if (S.lastTick && S.playing && now - S.lastTick < 2000) S.watchedSince += (now - S.lastTick) / 1000;
  S.lastTick = now;
}

/** Tell the host where we are (for "resume where I left off" and the watch-time counter). */
function reportPosition(ended) {
  if (!S.current) return;
  const t = currentTime(), d = duration();
  if (!ended && S.current.trimEnd > 0 && t >= S.current.trimEnd - 1) ended = true;
  host.post({ type: 'position', id: S.current.id, t: round1(t), d: round1(d), ended: !!ended, watched: round1(S.watchedSince) });
  S.watchedSince = 0;
  S.lastReportAt = Date.now();
}
setInterval(() => { if (S.playing && S.current && !S.current._done) reportPosition(false); }, 5000);

// ------------------------------------------------------------------ volume

function fadeInVolume() {
  clearInterval(S.fadeTimer);
  if (isYt()) {
    let v = Math.round(S.volume * 0.3);
    S.fadeTimer = setInterval(() => {
      v = Math.min(S.volume, v + Math.max(1, S.volume / 12));
      try { S.ytPlayer.setVolume(v); } catch (e) {}
      if (v >= S.volume) clearInterval(S.fadeTimer);
    }, 120);
    return;
  }
  const target = S.volume / 100;
  if (video.muted || target === 0) { video.volume = target; return; }
  let v = Math.min(video.volume, target);
  S.fadeTimer = setInterval(() => {
    v = Math.min(target, v + target / 14);
    video.volume = v;
    if (v >= target) clearInterval(S.fadeTimer);
  }, 100);
}

function setVolume(v, announce = true) {
  S.volume = clamp(Math.round(v), 0, 100);
  if (S.volume > 0 && S.muted) S.muted = false;
  clearInterval(S.fadeTimer);
  video.muted = S.muted;
  video.volume = S.volume / 100;
  applyYtVolume(false);
  $('vol').value = S.volume;
  syncMuteUi();
  if (announce) toast(S.muted ? 'Muted' : `Volume ${S.volume}%`);
  host.post({ type: 'volume', volume: S.volume, muted: S.muted });
}

function toggleMute() {
  S.muted = !S.muted;
  video.muted = S.muted;
  if (!S.muted && S.volume === 0) S.volume = 40;
  video.volume = S.volume / 100;
  applyYtVolume(false);
  syncMuteUi();
  toast(S.muted ? 'Muted' : `Sound on · ${S.volume}%`);
  host.post({ type: 'volume', volume: S.volume, muted: S.muted });
}

function syncMuteUi() { body.classList.toggle('muted', S.muted); }

// ------------------------------------------------------------------ "now playing" line, quotes, hints

function showNow(item) {
  $('now-badge').textContent = PLATFORM[item.platform] || 'Video';
  $('now-title').textContent = item.title || '';
  $('now-count').textContent = S.items.length > 1 ? `${S.index + 1} / ${S.items.length}` : '';
  body.classList.remove('now-dim');
  clearTimeout(S.nowTimer);
  S.nowTimer = setTimeout(() => body.classList.add('now-dim'), 7000);
}

function pickQuote() {
  const q = (S.cfg.overlay && S.cfg.overlay.quotes) || [];
  if (!q.length) return '';
  let i = Math.floor(Math.random() * q.length);
  if (q.length > 1 && q[i] === S.lastQuote) i = (i + 1) % q.length;
  S.lastQuote = q[i];
  return q[i];
}

function showQuote(then, ms = 5200) {
  const text = pickQuote();
  if (!text) { then && then(); return; }
  S.inQuote = true;
  S.lastQuoteAt = Date.now();
  $('quote-text').textContent = text;
  const o = S.cfg.overlay || {};
  $('quote-goal').textContent = o.goal && o.goalText ? o.goalText.split('\n')[0] : '';
  body.classList.add('quote-on');
  clearTimeout(S.quoteTimer);
  S.quoteThen = then;
  S.quoteTimer = setTimeout(endQuote, ms);
}

function cancelQuote() {
  clearTimeout(S.quoteTimer);
  S.quoteThen = null;
  S.inQuote = false;
  body.classList.remove('quote-on');
}

function endQuote() {
  clearTimeout(S.quoteTimer);
  body.classList.remove('quote-on');
  S.inQuote = false;
  const then = S.quoteThen; S.quoteThen = null;
  if (then) setTimeout(then, 350);
}

/** No (playable) videos: rotate quotes so the screen still pushes you. */
function startEmptyMode(message) {
  body.classList.add('empty', 'started');
  if (message) document.querySelector('#empty .empty-text').textContent = message;
  const cycle = () => {
    showQuote(null, 9000);
  };
  cycle();
  clearInterval(S.emptyTimer);
  S.emptyTimer = setInterval(cycle, 12000);
}

let hintTimer = 0;
function showHint(text, ms) {
  const h = $('hint');
  h.textContent = text;
  h.classList.add('on');
  clearTimeout(hintTimer);
  hintTimer = setTimeout(() => h.classList.remove('on'), ms);
}

let toastTimer = 0;
function toast(text) {
  const t = $('toast');
  t.textContent = text;
  t.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('on'), 1300);
}

// ------------------------------------------------------------------ input

function interactive() { return S.cfg && !(S.cfg.mode === 'idle' && S.cfg.closeOnInput); }

function showControls() {
  if (!interactive()) return;
  body.classList.add('controls-on', 'show-cursor');
  clearTimeout(S.controlsTimer);
  S.controlsTimer = setTimeout(() => {
    if (document.querySelector('#controls:hover')) { showControls(); return; }
    body.classList.remove('controls-on', 'show-cursor');
  }, 2600);
}

document.addEventListener('mousemove', (e) => {
  if (!S.cfg) return;
  if (!interactive()) return; // idle mode: the host closes us on real movement
  if (Math.abs(e.movementX) + Math.abs(e.movementY) > 2) showControls();
});

/** Returns true if the key was a player command. */
function handleKey(k, shift) {
  if (k === 'Escape' || k === 'q' || k === 'Q') host.post({ type: 'exit' });
  else if (k === ' ' || k === 'k' || k === 'K') { togglePause(); showControls(); }
  else if (k === 'ArrowRight' && shift || k === 'l' || k === 'L') seekBy(10);
  else if (k === 'ArrowLeft' && shift || k === 'j' || k === 'J') seekBy(-10);
  else if (k === 'ArrowRight' || k === 'n' || k === 'N' || k === 'MediaTrackNext') { next(); toast('Next'); }
  else if (k === 'ArrowLeft' || k === 'p' || k === 'P' || k === 'MediaTrackPrevious') { prev(); toast('Previous'); }
  else if (k === 'ArrowUp') setVolume(S.volume + 5);
  else if (k === 'ArrowDown') setVolume(S.volume - 5);
  else if (k === 'm' || k === 'M') toggleMute();
  else if (k === 'h' || k === 'H') { body.classList.toggle('no-overlays'); toast(body.classList.contains('no-overlays') ? 'Text hidden' : 'Text shown'); }
  else if (k === 'MediaPlayPause') togglePause();
  else return false;
  return true;
}
/** Keys captured by the app's keyboard hook while this window can't have focus (idle mode). */
window.__hostKey = (k, shift) => { if (S.cfg) handleKey(k, !!shift); };

document.addEventListener('keydown', (e) => {
  if (!S.cfg) return;
  if (!interactive()) { host.post({ type: 'input' }); return; }
  if (handleKey(e.key, e.shiftKey)) e.preventDefault();
});

document.addEventListener('mousedown', (e) => {
  if (!S.cfg) return;
  if (!interactive()) { host.post({ type: 'input' }); return; }
  if (e.target.closest('#controls')) return;
  if (e.button === 0) { togglePause(); showControls(); }
});

document.addEventListener('wheel', (e) => {
  if (!S.cfg) return;
  if (!interactive()) { host.post({ type: 'input' }); return; }
  setVolume(S.volume + (e.deltaY < 0 ? 5 : -5));
  showControls();
}, { passive: true });

document.addEventListener('dblclick', (e) => e.preventDefault());
document.addEventListener('contextmenu', (e) => e.preventDefault());

$('controls').addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const act = b.dataset.act;
  if (act === 'prev') prev();
  else if (act === 'next') next();
  else if (act === 'toggle') togglePause();
  else if (act === 'mute') toggleMute();
  else if (act === 'overlays') body.classList.toggle('no-overlays');
  else if (act === 'exit') host.post({ type: 'exit' });
  showControls();
});
$('vol').addEventListener('input', (e) => setVolume(+e.target.value, false));

// ------------------------------------------------------------------ utils

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function round1(v) { return Math.round((v || 0) * 10) / 10; }
function finiteOr(v, d) { return isFinite(v) ? v : d; }

/** Used by the app's self-test to see what the player is doing. */
window.__msState = () => ({
  mode: S.cfg && S.cfg.mode,
  items: S.items.length,
  index: S.index,
  id: S.current && S.current.id,
  title: S.current && S.current.title,
  yt: isYt(),
  time: round1(currentTime()),
  duration: round1(duration()),
  paused: isYt() ? null : video.paused,
  muted: S.muted,
  volume: S.volume,
  started: S.started,
  ambient: body.classList.contains('ambient'),
  quote: S.inQuote,
  empty: body.classList.contains('empty'),
  videoError: video.error ? video.error.code : null,
});
